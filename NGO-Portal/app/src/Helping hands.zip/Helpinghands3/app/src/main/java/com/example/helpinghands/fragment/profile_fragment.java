package com.example.helpinghands.fragment;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.helpinghands.setup_profile;
import com.example.helpinghands.sign_in_page;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.helpinghands.R;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class profile_fragment extends Fragment  {


    private Button sign_out_button;
    private ImageButton edit_profile;
    ImageView imageView;
    TextView full_name,emailid,phone_no;

    @Override
    public void onActivityCreated(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        imageView=getActivity().findViewById(R.id.profile_image);
        full_name=getActivity().findViewById(R.id.full_name);
        phone_no=getActivity().findViewById(R.id.phone_no);
        emailid=getActivity().findViewById(R.id.emailid);

    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        String currentid = user.getUid();
        DocumentReference reference;
        FirebaseFirestore firestore= FirebaseFirestore.getInstance();

        reference = firestore.collection("user").document(currentid);
        reference.get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {

                        if(task.getResult().exists()){

                            String fullnameResult= task.getResult().getString("name");
                            String emailidResult= task.getResult().getString("email");
                            String phonenoResult= task.getResult().getString("phoneNo");
                            String uriResult= task.getResult().getString("uri");

                            Picasso.get().load(uriResult).into(imageView);
                            full_name.setText(fullnameResult);
                            emailid.setText(emailidResult);
                            phone_no.setText(phonenoResult);



                        }else {
                            Intent intent= new Intent(getActivity(),setup_profile.class);
                            startActivity(intent);
                        }
                    }
                });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v=inflater.inflate(R.layout.profile_fragment, container, false);


          sign_out_button=v.findViewById(R.id.sign_out_button);
          edit_profile=v.findViewById(R.id.edit_profile);
          edit_profile.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Intent i1=new Intent(getActivity(), setup_profile.class);
                  startActivity(i1);
              }
          });
          sign_out_button.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  FirebaseAuth.getInstance().signOut();
                  Intent i=new Intent(getActivity(),sign_in_page.class);
                  i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                  startActivity(i);
              }
          });

        return v;
    }

}